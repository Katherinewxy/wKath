import pandas as pd

df = pd.read_csv('/Users/jiyapatil/PycharmProjects/testing/Informer2020-main/archive/101ms.csv')
df['date'] = pd.to_datetime(df['date'],  format= '%Y-%m-%d %H:%M:%S.%f')
print(df)

df.to_csv('/Users/jiyapatil/PycharmProjects/testing/Informer2020-main/archive/101milli.csv')
