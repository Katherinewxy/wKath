import pandas as pd

d = {'col 1': [1,2,3,4,5,6,7,8,9,10]}

df_raw = pd.DataFrame(data = d)


num_train = int(len(df_raw) * 0.7)
num_test = int(len(df_raw) * 0.2)
num_vali = len(df_raw) - num_train - num_test

print("num_train")
print(num_test)
print(num_vali)